package com.chainofresponsibility.q5;

public enum Formato {
  JSON,
  XML,
  CSV
}
