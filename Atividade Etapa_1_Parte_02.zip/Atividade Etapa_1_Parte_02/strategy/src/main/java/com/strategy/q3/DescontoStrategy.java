package com.strategy.q3;

public interface DescontoStrategy {
  double desconto(Produto produto);
}

