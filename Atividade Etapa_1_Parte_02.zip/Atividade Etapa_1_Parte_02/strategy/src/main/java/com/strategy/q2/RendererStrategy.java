package com.strategy.q2;

public interface RendererStrategy {
    
    void mostrarImagem();
}
