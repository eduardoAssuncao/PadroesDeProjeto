Uma livraria vende diversos artigos consistindo de Livros, Revistas e Jogos.

Há livros e revistas impressos e digitais.

A livraria possui Jogos e Tabuleiro e Jogos de Videogame, sendo o último o jogo físico ou digital.

No pagamento a vista, temos a seguinte política de desconto:

    - Livros, Revistas Físicos e Jogos de Tabuleiro: 30% de desconto.
    - Livros e Revistas digitais: 15% de desconto.
    - Não há desconto para Jogos de Videogame.

Porém, a livraria pode ter promoções especiais durante o ano, de modo que os descontos dos produtos podem mudar.